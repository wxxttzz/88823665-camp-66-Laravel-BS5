@extends('layouts.default')
@section('title')
    CAMP-66 | Product
@endsection
@section('body', 'layout-fixed sidebar-expand-lg bg-body-tertiary')
@section('content')
    <div class="app-wrapper">
        @include('components.header')
        @include('components.menu')
        <main class="app-main" style="background-image: url('{{ asset('img/bg.png') }}'); background-repeat: no-repeat; background-attachment: fixed; background-size: cover;">
            <div class="container rounded-5 bg-opacity-50 bg-dark p-5 my-5">
                <div class="row column-gap-5">
                    <!-- just header -->
                    <div class="card rounded-5 ps-5 col mb-5 mx-2 shadow" style="background-color: #292e39">
                        <h1 class="fw-bold mt-5" style="color: aquamarine">Multiplication Table <br>
                            <span class="fst-italic text-white fw-lighter">with Input!</span>
                        </h1>
                        <h6 class=" mt-2 text-white"> PHP_03 with
                            <span class="text-wrap text-black rounded-5 ps-2 pe-2"
                                style="background-color: aquamarine">Bootstrap</span> +
                            <span class="text-wrap text-black rounded-5 ps-2 pe-2"
                                style="background-color: aquamarine;">PHP</span>
                            +
                            <span class="text-wrap text-black rounded-5 ps-2 pe-2"
                                style="background-color: aquamarine;">Laravel</span>
                        </h6>
                    </div>
                    <!-- input form -->
                    <div class="card col rounded-5 mb-5 mx-2 p-5 shadow" style="background-color: #292e39">
                        <form action="" method="post">
                            @csrf
                            <!--input-->
                            <div class="w-75 mx-auto text-center">
                                <label class="form-label text-white fs-5" for="typeNumber">What number do you
                                    <span class="text-decoration-underline fw-bolder" style="color: aquamarine">want?</span>
                                </label>
                                <input type="number" id="typeNumber" name="typeNumber" class="form-control mt-2"
                                    placeholder="Only numbers are welcome here :)" />
                            </div>
                            <!--buttons-->
                            <div class="row mt-3 text-center">
                                <div class="col">
                                    <button type="reset" class="btn btn-outline-danger w-50"> Reset</button>
                                </div>
                                <div class="col">
                                    <button type="submit" name="submit" class="btn btn-success w-50"> GO!</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- PHP/Output -->
                <div class="row mb-5">
                    <?php
                    if (isset($number)) {
                        mulTable($number);
                    }
                    ?>
                </div>
                <!-- footer -->
                <div class="card col rounded-5 mt-5 shadow text-center p-5" style="background-color: #292e39">
                    <div class="col">
                        <h6 class="text-white"> Crafted with 💖 by Patyot S.
                            <span class="text-wrap text-black fw-lighter rounded-5 ps-2 pe-2 pb"
                                style="background-color: aquamarine">(66160109)</span>
                        </h6>
                        <a class="bi bi-github h1 text-white mt-3"
                            href="https://github.com/1acto/88823665-camp-66/tree/PHP"></a>
                    </div>
                </div>
            </div>
        </main>
    </div>
@endsection
@section('scripts')
<?php
function mulTable(int $temp): void
{
    echo "<div class='col'>";
    echo "<div class='card mt-3 p-4 text-center rounded-5 shadow' style='background-color: #292e39'>";
    echo "<h1 class='mt-3 mb-3 fw-bold' style='color:aquamarine'>Mul-Table: $temp</h1>";
    echo "<div class='row'>";
    for ($f = 1; $f <= 12; $f++) {
        echo "<div class='col-12 mt-1 text-white'>";
        echo "<p class='fst-italic'> $temp x $f = <span class='fw-bold' style='color: aquamarine'>" . $temp * $f . '</span></p>';
        echo '</div>';
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
}
?>
@endsection
